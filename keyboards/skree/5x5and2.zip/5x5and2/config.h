// Dactyl Manuform Hotswap
#pragma once

// Basic Config

#ifndef WYLD_QMK_FIRMWARE_CONFIG_H
#define WYLD_QMK_FIRMWARE_CONFIG_H

#endif // WYLD_QMK_FIRMWARE_CONFIG_H

#define USE_SERIAL//define these!!!!!
#define SPLIT_HAND_PIN      GP28  // high = left, low = right     define these!!!!!

// Using Serial instead of I2C
#define SERIAL_USART_FULL_DUPLEX //define these!!!!!
#define SERIAL_USART_TX_PIN GP0//define these!!!!!
#define SERIAL_USART_RX_PIN GP1//define these!!!!!
#define SERIAL_PIO_USE_PIO0
#define SERIAL_USART_TIMEOUT     100  // USART driver timeout. default 100
#define SERIAL_USART_SPEED 921600//define these!!!!!
#define SERIAL_USART_PIN_SWAP//define these!!!!!

#define RP2040_BOOTLOADER_DOUBLE_TAP_RESET
#define RP2040_BOOTLOADER_DOUBLE_TAP_RESET_TIMEOUT 200U
#define RP2040_BOOTLOADER_DOUBLE_TAP_RESET_LED_MASK 0U

/* key matrix size */
// Rows are doubled-up
#define MATRIX_ROWS 12
#define MATRIX_COLS 5

#define MATRIX_COL_PINS { GP10, GP9, GP11, GP12, GP13, GP14 } //define these!!!!!
// 
#define MATRIX_ROW_PINS { GP18, GP21, GP17, GP20, GP16, GP15 } //define these!!!!!
// 
#define DIODE_DIRECTION COL2ROW


// #define POINTING_DEVICE_COMBINED
//#define SPLIT_POINTING_ENABLE
//#define POINTING_DEVICE_INVERT_Y
//#define ROTATIONAL_TRANSFORM_ANGLE  -25
//#define POINTING_DEVICE_RIGHT
//#define PMW33XX_CS_PIN GP5
//#define POINTING_DEVICE_TASK_THROTTLE_MS 1
//#define PMW33XX_LIFTOFF_DISTANCE 0x02
//#define POINTING_DEVICE_AUTO_MOUSE_ENABLE
// only required if not setting mouse layer elsewhere
//#define AUTO_MOUSE_DEFAULT_LAYER 3

#define DYNAMIC_KEYMAP_LAYER_COUNT 5

#define SPLIT_TRANSACTION_IDS_KB RPC_ID_KB_CONFIG_SYNC

//#define ENCODERS_PAD_A { }
//#define ENCODERS_PAD_B { }
//#define ENCODER_RESOLUTIONS { }
//#define ENCODERS_PAD_A_RIGHT { GP10, GP22 }
//#define ENCODERS_PAD_B_RIGHT { GP7, GP8 }
//#define ENCODER_RESOLUTIONS_RIGHT { 2 }


//// Sensor Notes ////
//// Pi Pico pins ////
#ifdef OLED_ENABLE
#define I2C_DRIVER I2CD0
#define I2C1_SDA_PIN GP26
#define I2C1_SCL_PIN GP27
// OLED Options
#define SPLIT_OLED_ENABLE
#define SPLIT_WPM_ENABLE
#define OLED_DISPLAY_WIDTH 128
#define OLED_DISPLAY_HEIGHT 32
#define OLED_MATRIX_SIZE 512
#define OLED_RESET -1
#define OLED_DISPLAY_ADDRESS 0x3C
#define OLED_BRIGHTNESS 255
#define OLED_TIMEOUT 32000
#define OLED_FADE_OUT
#define OLED_FADE_OUT_INTERVAL 0
#endif

#define RGB_MATRIX_FRAMEBUFFER_EFFECTS
#define RGB_MATRIX_KEYPRESSES

// Misc settings
// Mechanical locking support. Use KC_LCAP, KC_LNUM or KC_LSCR instead in keymap
#define LOCKING_SUPPORT_ENABLE
// Locking resynchronize hack
#define LOCKING_RESYNC_ENABLE// Enables This makes it easier for fast typists to use dual-function keys
#define PERMISSIVE_HOLD
// End of Basic Config
#define SPLIT_LAYER_STATE_ENABLE

#ifdef RGBLIGHT_ENABLE
#define WS2812_DI_PIN GP8
#define RGBLED_NUM 76
#define RGBLED_SPLIT { 38, 38 }
#define RGBLIGHT_EFFECT_ALTERNATING
#define RGBLIGHT_EFFECT_BREATHING
#define RGBLIGHT_EFFECT_RAINBOW_MOOD
#define RGBLIGHT_EFFECT_RAINBOW_SWIRL
#define RGBLIGHT_EFFECT_SNAKE
#define RGBLIGHT_EFFECT_STATIC_GRADIENT
#define RGBLIGHT_EFFECT_TWINKLE
#endif